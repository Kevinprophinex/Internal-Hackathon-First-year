<?php
// (A) DO YOUR PAYMENT & ORDER PROCESSING
// LET'S SAY PAYMENT + CHECKOUT OK - ORDER ID 999, COMMISSION AMOUNT OWED IS $87.65
$orderID = 999;
$commission = 87.65;

// (B) REGISTER COMMISSION
require "2-lib.php";
$pass = $REF->commission($orderID, $commission);
echo $pass ? "OK" : $REF->error ;
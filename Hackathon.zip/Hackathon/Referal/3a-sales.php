<?php
// (A) REGISTER REFERRAL CODE (IF ANY)
require "2-lib.php";
$REF->set();

// (B) HTML SALES PAGE ?>
<!DOCTYPE html>
<html>
  <head>
    <title>DUMMY SALES PAGE</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="x-dummy.css">
  </head>
  <body>
    <img src="sales.png">
    <p>Sales pitch here - Buy now and get this that everything!</p>

    <div class="note"><?php
      if (isset($_SESSION["referral"])) {
        echo "Current referral - ";
        print_r($_SESSION["referral"]);
      } else {
        echo "No referral set - Please access this page with 3a-sales.php?ref=jondoe";
      }
    ?></div>

    <form method="post" action="3b-checkout.php">
      <input type="submit" value="BUY NOW!">
    </form>
  </body>
</html>
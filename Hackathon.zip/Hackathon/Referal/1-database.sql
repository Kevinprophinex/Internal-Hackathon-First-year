-- (A) AFFILIATES TABLE
CREATE TABLE `affiliates` (
  `ref_code` varchar(32) NOT NULL,
  `aff_email` varchar(255) NOT NULL,
  `aff_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE `affiliates`
  ADD PRIMARY KEY (`ref_code`),
  ADD UNIQUE KEY `aff_email` (`aff_email`),
  ADD KEY `aff_name` (`aff_name`);

-- (B) COMMISSIONS TABLE
CREATE TABLE `commissions` (
  `ref_code` varchar(32) NOT NULL,
  `comm_date` datetime NOT NULL DEFAULT current_timestamp(),
  `comm_amount` decimal(10,2) NOT NULL,
  `order_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE `commissions`
  ADD PRIMARY KEY (`ref_code`,`comm_date`);

-- (C) DUMMY AFFILIATE
INSERT INTO `affiliates` (`ref_code`, `aff_email`, `aff_name`) VALUES
  ('jondoe', 'jon@doe.com', 'Jon Doe');
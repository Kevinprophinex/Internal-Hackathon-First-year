<?php
class Referral {
  // (A) CONSTRUCTOR - CONNECT TO DATABASE
  private $pdo;
  private $stmt;
  public $error;
  function __construct () {
    $this->pdo = new PDO(
      "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=".DB_CHARSET,
      DB_USER, DB_PASSWORD, [
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_NAMED
    ]);
  }

  // (B) DESTRUCTOR - CLOSE DATABASE CONNECTION
  function __destruct () {
    $this->pdo = null;
    $this->stmt = null;
  }

  // (C) HELPER - RUN SQL QUERY
  function query ($sql, $data=null) : void {
    $this->stmt = $this->pdo->prepare($sql);
    $this->stmt->execute($data);
  }

  // (D) REGISTER REFERRAL CODE - FIRST COME FIRST SERVE
  // I.E. CUSTOMER ACCESS YOUR SITE WITH 2 REFERRAL CODES.
  // THE FIRST REFERRAL CODE WILL BE VALID FOR 24 HRS.
  // THE SECOND REFERRAL CODE WILL NOT OVERRIDE THE FIRST.
  function set () {
    // (D1) CHECK IF EXISTING REFERRAL CODE HAS EXPIRED
    if (isset($_SESSION["referral"])) {
      if (strtotime("now") >= ($_SESSION["referral"]["t"] + REF_VALID)) {
        unset($_SESSION["referral"]);
      }
    }

    if (!isset($_SESSION["referral"]) && isset($_GET["ref"])) {
      // (D2) CHECK IF VALID AFFILIATE MEMBER
      $this->query("SELECT * FROM `affiliates` WHERE `ref_code`=?", [$_GET["ref"]]);
      $aff = $this->stmt->fetch();

      // (D3) REGISTER INTO SESSION IF VALID
      if (is_array($aff)) {
        $_SESSION["referral"] = [
          "c" => $aff["ref_code"],
          "t" => strtotime("now")
        ];
      }

      // (D4) INVALID REFERRAL CODE
      else {
        $this->error = "Invalid referral code";
        return false;
      }
    }
    return true;
  }

  // (E) REGISTER SALES COMMISSION
  function commission ($oid, $amt) {
    if (isset($_SESSION["referral"])) {
      // (E1) CHECK IF EXISTING REFERRAL CODE EXPIRED
      if (strtotime("now") >= ($_SESSION["referral"]["t"] + REF_VALID)) {
        unset($_SESSION["referral"]);
        $this->error = "Referral code expired";
        return false;
      }

      // (E2) REGISTER COMMISSIONS
      $this->query(
        "INSERT INTO `commissions` (`ref_code`, `comm_amount`, `order_id`) VALUES (?,?,?)",
        [$_SESSION["referral"]["c"], $amt, $oid]
      );

      // (E3) UP TO YOU - KEEP REFERRAL CODE AFTER SALES?
      unset($_SESSION["referral"]);
      return true;
    }
  }
}

// (F) SETTINGS - CHANGE THESE TO YOUR OWN!
define("DB_HOST", "localhost");
define("DB_NAME", "test");
define("DB_CHARSET", "utf8mb4");
define("DB_USER", "root");
define("DB_PASSWORD", "");
define("REF_VALID", 86400); // 24 hours = 86400 secs

// (G) START SEESSION + CREATE NEW REFERRAL OBJECT
session_start();
$REF = new Referral();